
#define X_MAX_PIXEL	        80
#define Y_MAX_PIXEL	        160


