#ifndef __FONT_H
#define __FONT_H		

extern  unsigned char code image[];
extern unsigned char code hanzi[];
extern unsigned char code asc2_1608[1520];
					  		 
#endif  
	 
	 



